import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaQrcode, FaVideo, FaMousePointer, FaChartLine, FaSync, FaShieldAlt,
  FaCheck, FaChevronDown, FaChevronUp, FaStar, FaArrowRight,
  FaTwitter, FaLinkedin, FaGithub, FaEnvelope, FaPhone,
  FaPlay, FaUsers, FaGlobe, FaRocket, FaBolt, FaCrown
} from 'react-icons/fa';
import { QRCodeSVG } from 'qrcode.react';
import Splide from '@splidejs/splide';
import '@splidejs/splide/css';
import './MarketingWebsite.css';

const Features = () => {
  const features = [
    { icon: <FaSync />, title: 'Dynamic QR Codes', desc: 'Update QR codes anytime without reprinting. Change video, CTA, or destination URL instantly.' },
    { icon: <FaVideo />, title: 'Video Landing Pages', desc: 'Branded mobile-first landing pages with YouTube, Vimeo, or MP4 video content.' },
    { icon: <FaMousePointer />, title: 'Configurable CTAs', desc: 'Add customizable Call-to-Action buttons. Redirect to Amazon, Flipkart, or any destination.' },
    { icon: <FaChartLine />, title: 'Real-Time Analytics', desc: 'Track scans, unique visitors, CTA clicks, device types, and locations live.' },
    { icon: <FaQrcode />, title: 'QR Branding', desc: 'Add your company logo inside QR codes for professional branding.' },
    { icon: <FaShieldAlt />, title: 'Secure & Scalable', desc: 'Enterprise-grade security with HTTPS and scalable infrastructure.' }
  ];

  return (
    <section className="mk-section" id="features">
      <div className="container">
        <div className="text-center mb-4">
          <span className="mk-badge">FEATURES</span>
          <h2 className="mk-heading">Everything You Need for<br/><span className="mk-gradient-text">Smart QR Marketing</span></h2>
          <p className="mk-subtext">Powerful features to create, manage, and track your QR <span className='d-lg-block d-sm-inline'>campaigns</span> </p>
        </div>
        <div className="row">
          {features.map((f, i) => (
            <div key={i} className="col-md-6 col-lg-4 col-sm-12 mb-3">
              <div className="mk-feature-card">
                <div className="mk-feature-icon">{f.icon}</div>
                <h5 className="mk-feature-title">{f.title}</h5>
                <p className="mk-feature-desc">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const HowItWorks = () => {
  const steps = [
    { num: '01', title: 'Create QR Code', desc: 'Generate a dynamic QR code from the admin panel with your brand logo.' },
    { num: '02', title: 'Set Up Landing Page', desc: 'Attach video, campaign content, and CTA button to your branded page.' },
    { num: '03', title: 'Customer Scans QR', desc: 'Customer scans and is taken to your branded landing page with video.' },
    { num: '04', title: 'Track & Optimize', desc: 'Monitor analytics, track clicks, and update content anytime.' }
  ];

  return (
    <section className="mk-section mk-section-alt" id="how-it-works">
      <div className="container">
        <div className="text-center mb-4">
          <span className="mk-badge">HOW IT WORKS</span>
          <h2 className="mk-heading">Simple <span className="mk-gradient-text">4-Step</span> Process</h2>
          <p className="mk-subtext">From creation to tracking, everything is streamlined</p>
        </div>
        <div className="row">
          {steps.map((s, i) => (
            <div key={i} className="col-md-6 col-lg-3 col-sm-12 mb-3">
              <div className="mk-step-card">
                <div className="mk-step-num">{s.num}</div>
                <div className="mk-step-line"></div>
                <h5 className="mk-step-title">{s.title}</h5>
                <p className="mk-step-desc">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Stats = () => {
  return (
    <section className="mk-section mk-stats-section">
      <div className="container">
        <div className="text-center mb-4">
          <span className="mk-badge">OUR IMPACT</span>
          <h2 className="mk-heading">Metrics that <span className="mk-gradient-text">Matter</span></h2>
          <p className="mk-subtext">Join thousands of businesses scaling their marketing with AKKSYS</p>
        </div>
        <div className="row text-center">
          <div className="col-md-6 col-sm-12 col-lg-3 mb-3 mb-lg-0">
            <div className="mk-stat-card">
              <div className="mk-stat-icon"><FaQrcode /></div>
              <h3 className="mk-stat-number">10,000+</h3>
              <p className="mk-stat-label">QR Codes Generated</p>
            </div>
          </div>
          <div className="col-md-6 col-sm-12 col-lg-3 mb-3 mb-lg-0">
            <div className="mk-stat-card">
              <div className="mk-stat-icon"><FaUsers /></div>
              <h3 className="mk-stat-number">2.4M+</h3>
              <p className="mk-stat-label">Total Scans</p>
            </div>
          </div>
          <div className="col-md-6 col-sm-12 col-lg-3 mb-3 mb-lg-0">
            <div className="mk-stat-card">
              <div className="mk-stat-icon"><FaGlobe /></div>
              <h3 className="mk-stat-number">500+</h3>
              <p className="mk-stat-label">Businesses</p>
            </div>
          </div>
          <div className="col-md-6 col-sm-12 col-lg-3 mb-3 mb-lg-0">
            <div className="mk-stat-card">
              <div className="mk-stat-icon"><FaStar /></div>
              <h3 className="mk-stat-number">4.9/5</h3>
              <p className="mk-stat-label">Customer Rating</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Pricing = () => {
  const plans = [
    { name: 'Starter', price: 'Free', period: 'forever', desc: 'Perfect for trying out QR marketing', features: ['3 Dynamic QR Codes', 'Basic Analytics', 'YouTube/Vimeo Support', 'Standard Landing Page', 'Email Support'], cta: 'Get Started Free', popular: false, icon: <FaRocket /> },
    { name: 'Professional', price: '₹999', period: '/month', desc: 'For growing businesses', features: ['50 Dynamic QR Codes', 'Advanced Analytics', 'Custom Video (MP4)', 'Branded Landing Pages', 'QR Logo Branding', 'Bulk Generation', 'Priority Support'], cta: 'Start Free Trial', popular: true, icon: <FaBolt /> },
    { name: 'Enterprise', price: 'Custom', period: '', desc: 'For large-scale operations', features: ['Unlimited QR Codes', 'Full Analytics Suite', 'Custom Integrations', 'White-Label Solution', 'Dedicated Support', 'SLA Guarantee', 'API Access'], cta: 'Contact Sales', popular: false, icon: <FaCrown /> }
  ];

  return (
    <section className="mk-section mk-section-alt" id="pricing">
      <div className="container">
        <div className="text-center mb-5">
          <span className="mk-badge">PRICING</span>
          <h2 className="mk-heading">Simple, Transparent <span className="mk-gradient-text">Pricing</span></h2>
          <p className="mk-subtext">Choose the plan that fits your business</p>
        </div>
        <div className="row justify-content-center">
          {plans.map((p, i) => (
            <div key={i} className="col-md-6 col-lg-4 col-sm-12 mb-3">
              <div className={`mk-pricing-card ${p.popular ? 'mk-popular' : ''}`}>
                <div>
                  {p.popular && <div className="mk-popular-badge">MOST POPULAR</div>}
                <div className="mk-pricing-icon">{p.icon}</div>
                <h5 className="mk-plan-name">{p.name}</h5>
                <div className="mk-price">
                  <span className="mk-price-amount">{p.price}</span>
                  <span className="mk-price-period">{p.period}</span>
                </div>
                <p className="mk-plan-desc">{p.desc}</p>
                <ul className="mk-plan-features"> 
                  {p.features.map((f, j) => <li key={j}><FaCheck className="mk-check" /> {f}</li>)}
                </ul>
                </div>

                <div>
                  <button style={{padding : "14px 0"}} className={`thm-btn w-100 ${p.popular ? 'thm-btn' : 'thm-btn outline'}`}>{p.cta}</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  const items = [
    { name: 'Rahul Sharma', role: 'Marketing Head, TechIndia', text: 'AKKSYS transformed our product packaging. We update QR codes for every campaign without reprinting. Analytics are game-changing.', avatar: 'RS' },
    { name: 'Priya Patel', role: 'E-commerce Manager, ShopLocal', text: 'The dynamic QR feature saved us thousands. One QR code now serves multiple campaigns throughout the year. Highly recommended!', avatar: 'PP' },
    { name: 'Amit Kumar', role: 'Founder, StartupHub', text: 'Simple to use, powerful analytics. Our scan rates increased 300% after switching to AKKSYS from static QR generators.', avatar: 'AK' },
    { name: 'Neha Gupta', role: 'CEO, FashionHub', text: 'Best QR platform we have used. The video landing pages are amazing and our customers love the experience.', avatar: 'NG' },
    { name: 'Vikram Singh', role: 'Marketing Lead, TechCorp', text: 'ROI doubled in just 3 months. The real-time analytics help us optimize campaigns on the fly.', avatar: 'VS' }
  ];

  React.useEffect(() => {
    const splide = new Splide('.mk-testimonial-slider', {
      type: 'loop',
      perPage: 3,
      focus: 'center',
      perMove: 1,
      gap: '24px',
      autoplay: true,
      interval: 3000,
      pauseOnHover: true,
      pagination: true,
      arrows: false,
      breakpoints: {
        992: { perPage: 2 },
        576: { perPage: 1, gap: '16px' }
      }
    });
    splide.mount();
    return () => splide.destroy();
  }, []);

  return (
    <section className="mk-section" id="testimonials">
      <div className="container">
        <div className="text-center mb-4">
          <span className="mk-badge">TESTIMONIALS</span>
          <h2 className="mk-heading">Loved by <span className="mk-gradient-text">Businesses</span></h2>
          <p className="mk-subtext">See what our customers have to say</p>
        </div>
        <div className="mk-testimonial-slider splide">
          <div className="splide__track">
            <ul className="splide__list">
              {items.map((t, i) => (
                <li key={i} className="splide__slide">
                  <div className="mk-testimonial-card">
                    <div className="mk-testimonial-stars">
                      <FaStar /><FaStar /><FaStar /><FaStar /><FaStar />
                    </div>
                    <p className="mk-testimonial-text">"{t.text}"</p>
                    <div className="mk-testimonial-author">
                      <div className="mk-testimonial-avatar">{t.avatar}</div>
                      <div>
                        <div className="mk-testimonial-name">{t.name}</div>
                        <div className="mk-testimonial-role">{t.role}</div>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(null);
  const faqs = [
    { q: 'What is a Dynamic QR Code?', a: 'A Dynamic QR Code lets you change the destination URL or content anytime without changing the physical QR code.' },
    { q: 'Can I track how many people scanned my QR code?', a: 'Yes! AKKSYS provides real-time analytics including total scans, unique scans, CTA clicks, device info, and location data.' },
    { q: 'What video formats are supported?', a: 'We support YouTube, Vimeo, and MP4 files. For Phase 1, we recommend YouTube/Vimeo to avoid storage costs.' },
    { q: 'How does the CTA redirect work?', a: 'When a user scans your QR and watches the video, they see a CTA button. Clicking it redirects them to your configured destination.' },
    { q: 'Can I use my own logo in the QR code?', a: 'Yes! AKKSYS supports QR branding where you can add your company logo to the center of the QR code.' },
    { q: 'Is there a limit on QR code scans?', a: 'No! There is no limit on the number of scans. Your QR codes can be scanned unlimited times.' }
  ];

  return (
    <section className="mk-section mk-section-alt" id="faq">
      <div className="container">
        <div className="text-center mb-4">
          <span className="mk-badge">FAQ</span>
          <h2 className="mk-heading">Frequently Asked <span className="mk-gradient-text">Questions</span></h2>
          <p className="mk-subtext">Got questions? We've got answers</p>
        </div>
        <div className="row justify-content-center">
          <div className="col-lg-10">
            {faqs.map((faq, i) => (
              <div key={i} className={`mk-faq-item ${openIndex === i ? 'active' : ''}`} onClick={() => setOpenIndex(openIndex === i ? null : i)}>
                <div className="mk-faq-question">
                  <span>{faq.q}</span>
                  {openIndex === i ? <FaChevronUp /> : <FaChevronDown />}
                </div>
                {openIndex === i && <div className="mk-faq-answer">{faq.a}</div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const CTASection = () => {
  const navigate = useNavigate();

  return (
    <section className="mk-section mk-cta-section">
      <div className="container">
        <div className="mk-cta-box">
          <div className="mk-cta-content">
            <h2 className="mk-cta-title">Ready to Transform Your QR Marketing?</h2>
            <p className="mk-cta-desc">Join 500+ businesses using AKKSYS to create dynamic, trackable QR codes</p>
            <div className="mk-cta-buttons">
              <button className="thm-btn" style={{ padding: '14px 32px', fontSize: '16px' }} onClick={() => navigate('/admin')}>
                Get Started Free <FaArrowRight className="ms-2" />
              </button>
              <button className="thm-btn outline" style={{ padding: '14px 32px', fontSize: '16px' }} onClick={() => navigate('/demo')}>
                <FaPlay className="me-2" /> Watch Demo
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="mk-footer">
    <div className="container">
      <div className="row ">
        <div className="col-lg-4 mb-0 mb-lg-5">
          <div className="d-flex align-items-center gap-2 mb-3">
            <div className="mk-footer-logo"><FaQrcode /></div>
            <span className="mk-footer-brand">AKKSYS</span>
          </div>
          <p className="mk-footer-desc">Dynamic QR platform for smart marketing. Create, manage, and track QR code campaigns.</p>
          <div className="d-flex gap-3 mb-3 mb-lg-0">
            <a href="#" className="mk-social"><FaTwitter /></a>
            <a href="#" className="mk-social"><FaLinkedin /></a>
            <a href="#" className="mk-social"><FaGithub /></a>
          </div>
        </div>
        <div className="col-md-6 col-lg-2 col-sm-12">
          <h6 className="mk-footer-heading">Product</h6>
          <ul className="mk-footer-links">
            <li><a href="#features">Features</a></li>
            <li><a href="#pricing">Pricing</a></li>
            <li><a href="#">QR Generator</a></li>
            <li><a href="#">Analytics</a></li>
          </ul>
        </div>
        <div className="col-md-6 col-lg-2 col-sm-12">
          <h6 className="mk-footer-heading">Company</h6>
          <ul className="mk-footer-links">
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Careers</a></li>
          </ul>
        </div>
        <div className="col-md-6 col-lg-2 col-sm-12">
          <h6 className="mk-footer-heading">Support</h6>
          <ul className="mk-footer-links">
            <li><a href="#">Help Center</a></li>
            <li><a href="#">Documentation</a></li>
            <li><a href="#">API Reference</a></li>
            <li><a href="#">Status</a></li>
          </ul>
        </div>
        <div className="col-md-6 col-lg-2 col-sm-12">
          <h6 className="mk-footer-heading">Legal</h6>
          <ul className="mk-footer-links">
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Terms of Service</a></li>
            <li><a href="#">Cookie Policy</a></li>
            <li><a href="#">GDPR</a></li>
          </ul>
        </div>
      </div>
      <div className="mk-footer-bottom">
        <div className="row align-items-center">
          <div className="col-md-6">
            <p className="mk-footer-copy">&copy; 2026 AKKSYS. All rights reserved.</p>
          </div>
          <div className="col-md-6 text-md-end">
            <span className="mk-footer-contact"><FaEnvelope className="me-1" /> hello@akksys.in</span>
            <span className="mk-footer-contact ms-3"><FaPhone className="me-1" /> +91 98765 43210</span>
          </div>
        </div>
      </div>
    </div>
  </footer>
);

const MarketingWebsite = () => {
  const navigate = useNavigate();

  return (
    <div className="mk-container">
      {/* Navbar */}
      <nav className="mk-nav">
        <div className="container d-flex justify-content-between align-items-center py-3">
          <div className="d-flex align-items-center gap-2">
            <div className="mk-nav-logo"><FaQrcode /></div>
            <span className="mk-nav-brand">AKKSYS</span>
          </div>
          <div className="d-none d-md-flex gap-4">
            <a href="#features" className="mk-nav-link">Features</a>
            <a href="#how-it-works" className="mk-nav-link">How It Works</a>
            <a href="#pricing" className="mk-nav-link">Pricing</a>
            <a href="#faq" className="mk-nav-link">FAQ</a>
          </div>
          <div className="d-flex align-items-center gap-2">
            <button className="thm-btn outline" onClick={() => navigate('/admin')}>Admin</button>
            <button className="thm-btn" onClick={() => navigate('/login')}>Login</button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="mk-hero">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-6">
              <span className="mk-badge mk-badge-hero mb-2">
                <span className="mk-dot"></span> Dynamic QR Platform — Phase 1
              </span>
              <h1 className="mk-hero-title mb-2">
                One QR.<br/>
                <span className="mk-gradient-text">Infinite Possibilities.</span>
              </h1>
              <p className="mk-hero-subtitle">
                Dynamic QR codes linking to branded mobile landing pages with video, configurable CTAs, and real-time analytics.
              </p>
              <div className="d-flex gap-3 mb-4">
                <button className="thm-btn" onClick={() => navigate('/admin')}>
                  Generate QR Free <FaArrowRight />
                </button>
                <button className="thm-btn outline" onClick={() => navigate('/demo')}>
                  <FaPlay /> Watch Demo
                </button>
              </div>
              <div className="row">
                <div className="col-4">
                  <h3 className="mk-hero-stat">10k+</h3>
                  <p className="mk-hero-stat-label">QR Codes Generated</p>
                </div>
                <div className="col-4">
                  <h3 className="mk-hero-stat">2.4M</h3>
                  <p className="mk-hero-stat-label">Total Scans Tracked</p>
                </div>
                <div className="col-4">
                  <h3 className="mk-hero-stat">99.9%</h3>
                  <p className="mk-hero-stat-label">Uptime SLA</p>
                </div>
              </div>
            </div>
            <div className="col-lg-6 d-flex align-items-center justify-content-center">
              <div className="mk-preview-card">
                <div className="text-center mb-2">
                  <p className="mk-preview-label">LIVE QR PREVIEW</p>
                  <div className="mk-qr-box">
                    <QRCodeSVG
                      value="https://akksys.in/q/xk9g2m"
                      size={150}
                      bgColor="#ffffff"
                      fgColor="#100e14"
                      level="H"
                      includeMargin={false}
                    />
                    <div className="mk-qr-logo">
                      <div className="mk-qr-logo-inner">AK</div>
                    </div>
                  </div>
                  <h5 className="mk-preview-title">Product Demo QR</h5>
                  <p className="mk-preview-url">akksys.in/q/xk9g2m</p>
                </div>
                <div className="row g-2 mb-3">
                  <div className="col-6"><div className="mk-stat-box"><p className="mk-stat-labels">Scans</p><h5 className="mk-stat-value">1,247</h5></div></div>
                  <div className="col-6"><div className="mk-stat-box"><p className="mk-stat-labels">Unique</p><h5 className="mk-stat-value">892</h5></div></div>
                  <div className="col-6"><div className="mk-stat-box"><p className="mk-stat-labels">CTA Clicks</p><h5 className="mk-stat-value">427</h5></div></div>
                  <div className="col-6"><div className="mk-stat-box"><p className="mk-stat-labels">Active</p><h5 className="mk-stat-value">Yes</h5></div></div>
                </div>
                <div className="mk-stat-box d-flex align-items-center">
                  <span className="mk-dot me-2"></span>
                  <span className="mk-stat-cta">CTA: Buy Now → Amazon.in</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Features />
      <HowItWorks />
      <Stats />
      <Pricing />
      <Testimonials />
      <FAQ />
      <CTASection />
      <Footer />
    </div>
  );
};

export default MarketingWebsite;
